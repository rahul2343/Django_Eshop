from django.shortcuts import render,redirect
from store.models.costomer import Customer
from django.contrib.auth.hashers import make_password


def validationCustomer(customer):
    error_message = None
    if not customer.first_name:
        error_message = 'First name required !!'
    elif not customer.last_name:
        error_message = 'Last name required !!'
    elif not customer.email:
        error_message = 'E-mail is required'
    elif not customer.phone:
        error_message = 'Phone number required !!'
    elif len(customer.phone) < 10:
        error_message = '10 digit Number is required !!'
    elif not customer.passward:
        error_message = 'Password required !!'
    elif len(customer.passward) < 5:
        error_message = 'Minimum 5 char log pass required !!'
    elif customer.IsExist():
        error_message = 'E-mail Already registered'
    return error_message


def registerUser(request):
    first_name = request.POST.get('firstname')
    last_name = request.POST.get('lastname')
    phone = request.POST.get('phone')
    email = request.POST.get('email')
    password = request.POST.get('password')

    customer = Customer(first_name=first_name,
                        last_name=last_name,
                        phone=phone,
                        email=email,
                        passward=password)
    value = {
        'firstname': first_name,
        'lastname': last_name,
        'phone': phone,
        'email': email
    }
    error_message = validationCustomer(customer)
    if not error_message:
        customer.passward = make_password(customer.passward)
        customer.register()
        return redirect('login')
    else:
        data = {
            'error_message': error_message,
            'values': value
        }
        return render(request, 'signup.html', data)


def signup(request):
    if request.method == 'GET':
        return render(request, 'signup.html')
    else:
        return registerUser(request)