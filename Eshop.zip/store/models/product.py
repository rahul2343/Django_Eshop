from django.db import models
from .Category import Category


class Project(models.Model):
    name = models.CharField(max_length=20)
    price = models.IntegerField(default=0)
    category = models.ForeignKey(Category, on_delete=models.CASCADE,default=1)
    description = models.CharField(max_length=200 , default='', null=True, blank=True)
    image = models.ImageField(upload_to='upload/products/')

    @staticmethod
    def get_product_by_id(ids):
        return Project.objects.filter(id__in=ids)

    @staticmethod
    def get_all_products():
        return Project.objects.all()

    @staticmethod
    def get_all_products_by_Categoryid(category_id):
        if category_id:
            return Project.objects.filter(category=category_id)
        else:
            return Project.get_all_products()


    def __str__(self):
        return self.name